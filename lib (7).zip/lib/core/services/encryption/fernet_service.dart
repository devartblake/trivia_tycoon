import 'dart:convert';
import 'package:encrypt/encrypt.dart' hide Fernet;
import 'package:fernet/fernet.dart' as f;
import 'package:trivia_tycoon/core/services/storage/secure_storage.dart';

class FernetService {
  final SecureStorage secureStorage;

  FernetService(this.secureStorage);

  static Future<FernetService> initialize(SecureStorage storage) async {
    // Load or generate Fernet key, validate, etc.
    final service = FernetService(storage);
    await service._ensureFernetSecret();
    return service;
  }

  /// Ensure a Fernet key is stored or generate one
  Future<String> _ensureFernetSecret() async {
    final box = await secureStorage.getSecretBox();
    if (!box.containsKey('fernet_secret')) {
      final randomBytes = List<int>.generate(32, (_) => (DateTime.now().microsecond % 255));
      final base64Key = base64.encode(randomBytes);
      await box.put('fernet_secret', base64Key);
      return base64Key;
    }
    return box.get('fernet_secret');
  }

  /// Encrypt a string using Fernet
  Future<String> encrypt(String plainText) async {
    final keyStr = await _ensureFernetSecret();
    final key = Key.fromBase64(keyStr);
    final fernet = f.Fernet(key);
    final encrypted = fernet.encrypt(utf8.encode(plainText));
    return base64.encode(encrypted); // Store as base64 string
  }

  /// Decrypt a string using Fernet
  Future<String> decrypt(String token) async {
    try {
      final keyStr = await _ensureFernetSecret();
      final key = Key.fromBase64(keyStr);
      final fernet = f.Fernet(key);
      final decrypted = fernet.decrypt(base64.decode(token));
      return utf8.decode(decrypted);
    } catch (e) {
      return '❌ Fernet decryption failed: ${e.toString()}';
    }
  }
}

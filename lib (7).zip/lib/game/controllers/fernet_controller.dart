import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/encryption/fernet_service.dart';

class FernetController extends AsyncNotifier<FernetService> {
  @override
  Future<FernetService> build() async {
    return await FernetService.initialize();
  }

  Future<String> encrypt(String input) async {
    final service = state.valueOrNull ?? await future;
    return await service.encrypt(input);
  }

  Future<String> decrypt(String token) async {
    final service = state.valueOrNull ?? await future;
    return await service.decrypt(token);
  }
}

import 'package:hive/hive.dart';

/// PlayerProfileService handles saving and retrieving
/// player-specific information like name and role.
class PlayerProfileService {
  static const _boxName = 'settings';
  static const _playerNameKey = 'playerName';
  static const _userRoleKey = 'userRole';

  late final Box _box;

  /// Initializes the Hive box for settings.
  Future<void> init() async {
    _box = await Hive.openBox(_boxName);
  }

  /// Saves the player's name.
  Future<void> savePlayerName(String name) async {
    await _box.put(_playerNameKey, name);
  }

  /// Retrieves the player's name (defaults to 'Player').
  String getPlayerName() {
    return _box.get(_playerNameKey, defaultValue: 'Player');
  }

  /// Saves the player's role.
  Future<void> saveUserRole(String role) async {
    await _box.put(_userRoleKey, role);
  }

  /// Retrieves the player's role.
  String? getUserRole() {
    return _box.get(_userRoleKey);
  }

  /// Checks if player is admin based on role.
  bool isAdminUser() {
    return getUserRole() == 'admin';
  }
}
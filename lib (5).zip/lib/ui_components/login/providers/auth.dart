import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:trivia_tycoon/core/services/settings/app_settings.dart';
import 'package:trivia_tycoon/core/services/storage/secure_storage.dart';
import '../trivia_login.dart';

enum AuthMode { signup, login }
enum AuthType { provider, userPassword }

/// A callback for provider login actions.
/// Should return `null` on success or a `String` error message on failure.
typedef ProviderAuthCallback = Future<String?> Function();

/// Optional callback to determine if additional signup fields are required.
/// Should return `true` if extra signup fields should be shown.
typedef ProviderNeedsSignUpCallback = Future<bool> Function();

final authProvider = ChangeNotifierProvider<Auth>((ref) => Auth());

class Auth extends ChangeNotifier {
  Auth({
    this.loginProviders = const [],
    this.onLogin,
    this.onSignup,
    this.onRecoverPassword,
    this.onConfirmRecover,
    this.onConfirmSignup,
    this.confirmSignupRequired,
    this.onResendCode,
    this.beforeAdditionalFieldsCallback,
    String email = '',
    String password = '',
    String confirmPassword = '',
    AuthMode initialAuthMode = AuthMode.login,
    this.termsOfService = const [],
  })  : _email = email,
        _password = password,
        _confirmPassword = confirmPassword,
        _mode = initialAuthMode;

  final LoginCallback? onLogin;
  final SignupCallback? onSignup;
  final RecoverCallback? onRecoverPassword;
  final List<LoginProvider> loginProviders;
  final ConfirmRecoverCallback? onConfirmRecover;
  final ConfirmSignupCallback? onConfirmSignup;
  final ConfirmSignupRequiredCallback? confirmSignupRequired;
  final SignupCallback? onResendCode;
  final List<TermOfService> termsOfService;
  final BeforeAdditionalFieldsCallback? beforeAdditionalFieldsCallback;

  AuthType _authType = AuthType.userPassword;
  AuthType get authType => _authType;
  set authType(AuthType authType) {
    _authType = authType;
    notifyListeners();
  }

  AuthMode _mode = AuthMode.login;
  AuthMode get mode => _mode;
  set mode(AuthMode value) {
    _mode = value;
    notifyListeners();
  }

  bool get isLogin => _mode == AuthMode.login;
  bool get isSignup => _mode == AuthMode.signup;
  int currentCardIndex = 0;

  AuthMode opposite() => _mode == AuthMode.login ? AuthMode.signup : AuthMode.login;

  AuthMode switchAuth() {
    mode = opposite();
    return mode;
  }

  String _email = '';
  String get email => _email;
  set email(String email) {
    _email = email;
    notifyListeners();
  }

  String _password = '';
  String get password => _password;
  set password(String password) {
    _password = password;
    notifyListeners();
  }

  String _confirmPassword = '';
  String get confirmPassword => _confirmPassword;
  set confirmPassword(String confirmPassword) {
    _confirmPassword = confirmPassword;
    notifyListeners();
  }

  Map<String, String>? _additionalSignupData;
  Map<String, String>? get additionalSignupData => _additionalSignupData;
  set additionalSignupData(Map<String, String>? value) {
    _additionalSignupData = value;
    notifyListeners();
  }

  List<TermOfServiceResult> getTermsOfServiceResults() {
    return termsOfService.map((e) => TermOfServiceResult(term: e, accepted: e.checked)).toList();
  }
}

class AuthService {
  static const String _loggedInKey = 'isLoggedIn';

  static Future<bool> isLoggedIn() async {
    final value = await AppSettings.getBool(_loggedInKey);
    return value is bool ? value : false;
  }

  static Future<void> setLoggedIn(bool value) async {
    await AppSettings.setBool(_loggedInKey, value);
  }

  static Future<void> login(String email) async {
    // Save login flag to local storage
    await SecureStorage.setLoggedIn(true);
    await SecureStorage.setUserEmail(email);
  }

  static Future<void> logout() async {
    await AppSettings.setBool(_loggedInKey, false);
    await SecureStorage.setLoggedIn(false);
    await SecureStorage.removeUserEmail();
  }
}

// Callback typedefs

typedef LoginCallback = Future<String?>? Function(LoginData);
typedef SignupCallback = Future<String?>? Function(SignupData);
typedef RecoverCallback = Future<String?>? Function(String);
typedef ConfirmRecoverCallback = Future<String?>? Function(String, LoginData);
typedef ConfirmSignupCallback = Future<String?>? Function(String, LoginData);
typedef ConfirmSignupRequiredCallback = Future<bool> Function(LoginData);
typedef BeforeAdditionalFieldsCallback = Future<String?>? Function(SignupData);

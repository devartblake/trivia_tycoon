import 'package:flutter/material.dart';

class CreatedQuestionsTab extends StatelessWidget {
  const CreatedQuestionsTab({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: Text('Created Questions Screen')));
}
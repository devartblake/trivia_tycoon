import 'package:flutter/material.dart';

class QuestionHistoryScreen extends StatelessWidget {
  const QuestionHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Question history")),
      body: const Center(child: Text("Question history screen coming soon!")),
    );
  }
}

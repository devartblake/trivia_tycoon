import 'package:flutter/cupertino.dart';

class JoinQuizScreen extends StatelessWidget {
  const JoinQuizScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}
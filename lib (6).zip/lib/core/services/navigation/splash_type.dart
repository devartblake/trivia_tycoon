enum SplashType {
  mindMarket,
  empireRising,
  vaultUnlock,
  fortuneWheel,
  hqTerminal,
}
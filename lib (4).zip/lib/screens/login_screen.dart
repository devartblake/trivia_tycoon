import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart' show timeDilation;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:trivia_tycoon/core/services/app_cache_service.dart';
import 'package:trivia_tycoon/core/services/app_config_service.dart';
import 'package:trivia_tycoon/core/services/secure_storage.dart';

import '../components/login/models/login_data.dart';
import '../components/login/models/signup_data.dart';
import '../components/login/trivia_login.dart';
import '../core/constants/image_strings.dart';
import '../core/services/app_settings.dart';
import '../core/utils/hive_preferences.dart';
import 'onboarding/widget/constants.dart';

class LoginScreen extends StatelessWidget {
  static const routeName = '/auth';
  const LoginScreen({super.key});

  static const mockUsers = {
    'dribbble@gmail.com': '12345',
    'hunter@gmail.com': 'hunter',
    'near.huscarl@gmail.com': 'subscribe to pewdiepie',
    '@.com': '.',
  };

  Duration get loginTime => Duration(milliseconds: timeDilation.ceil() * 2250);

  Future<String?> _loginUser(LoginData data) async {
    // Simulate mock logic
    await Future.delayed(loginTime);
    if (!mockUsers.containsKey(data.name)) return 'User does not exist';
    if (mockUsers[data.name] != data.password) return 'Incorrect password';

    // App login logic
    await AuthService.login(data.name);
    await SecureStorage.setLoggedIn(true);
    await AppSettings.setString('userRole', 'admin'); // or 'user'

    final onboarded = await AppSettings.hasCompletedOnboarding();
    return null; // Success triggers `onSubmitAnimationCompleted`
  }

  Future<String?> _signupUser(SignupData data) async {
    await Future.delayed(loginTime);
    return null;
  }

  Future<String?> _recoverPassword(String name) async {
    await Future.delayed(loginTime);
    if (!mockUsers.containsKey(name)) return 'User not exists';
    return null;
  }

  Future<String?> _signupConfirm(String error, LoginData data) async {
    await Future.delayed(loginTime);
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return FlutterLogin(
      title: Constants.appName,
      logo: const AssetImage(tTriviaGameImage),
      logoTag: Constants.logoTag,
      titleTag: Constants.titleTag,
      navigateBackAfterRecovery: true,
      onConfirmRecover: _signupConfirm,
      onConfirmSignup: _signupConfirm,
      loginAfterSignUp: false,
      userValidator: (value) {
        if (!value!.contains('@') || !value.endsWith('.com')) {
          return "Email must contain '@' and end with '.com'";
        }
        return null;
      },
      passwordValidator: (value) {
        if (value!.isEmpty) return 'Password is empty';
        return null;
      },
      onLogin: _loginUser,
      onSignup: _signupUser,
      onRecoverPassword: _recoverPassword,
      onSubmitAnimationCompleted: () async {
        final hasOnboarded = await AppSettings.hasCompletedOnboarding();
        if (context.mounted) {
          context.go(hasOnboarded ? '/' : '/onboarding');
        }
      },
      additionalSignupFields: const [
        UserFormField(keyName: 'Username', icon: Icon(FontAwesomeIcons.userLarge)),
        UserFormField(keyName: 'Name'),
        UserFormField(keyName: 'Surname'),
        UserFormField(
          keyName: 'phone_number',
          displayName: 'Phone Number',
          userType: LoginUserType.phone,
        ),
      ],
      headerWidget: const IntroWidget(),
    );
  }
}

class IntroWidget extends StatelessWidget {
  const IntroWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        Text.rich(
          TextSpan(
            children: [
              TextSpan(text: "You are trying to login/sign up on server hosted on "),
              TextSpan(text: "example.com", style: TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          textAlign: TextAlign.justify,
        ),
        Row(
          children: <Widget>[
            Expanded(child: Divider()),
            Padding(padding: EdgeInsets.all(8.0), child: Text("Authenticate")),
            Expanded(child: Divider()),
          ],
        ),
      ],
    );
  }
}

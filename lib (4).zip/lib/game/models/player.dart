class Player {
  final String name;
  final int score;

  Player({required this.name, required this.score});
}


enum CurrencyType { coins, diamonds }

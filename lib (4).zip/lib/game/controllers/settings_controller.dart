import 'package:flutter/cupertino.dart';
import 'package:logging/logging.dart';
import 'package:trivia_tycoon/core/utils/hive_preferences.dart';

import '../../core/services/app_settings.dart';

/// Manages user settings like audio preferences and purchased songs
class SettingsController {
  static final _log = Logger('SettingsController');

  /// Whether all audio is enabled (override music and sounds).
  ValueNotifier<bool> audioOn = ValueNotifier(true);

  /// Whether sound effect are enabled.
  ValueNotifier<bool> soundsOn = ValueNotifier(true);

  /// Whether music is enabled.
  ValueNotifier<bool> musicOn = ValueNotifier(true);

  /// The player's name.
  ValueNotifier<String> playerName = ValueNotifier('Player');

  /// List of purchased songs
  ValueNotifier<List<String>> purchasedSongs = ValueNotifier([]);

  /// Loads settings from persistent storage.
  SettingsController() {
    _loadSettings();
  }

  /// Toggles the master audio setting.
  Future<void> toggleAudioOn() async {
    audioOn.value = !audioOn.value;
    await AppSettings.saveAudioOn(audioOn.value);
  }

  /// Toggles background music.
  Future<void> toggleMusicOn() async {
    musicOn.value = !musicOn.value;
    await AppSettings.saveMusicOn(musicOn.value);
  }

  /// Toggles sound effects.
  Future<void> toggleSoundsOn() async {
    soundsOn.value = !soundsOn.value;
    await AppSettings.saveSoundsOn(soundsOn.value);
  }

  /// Updates the player's name.
  Future<void> setPlayerName(String name) async {
    playerName.value = name;
    await AppSettings.savePlayerName(name);
  }

  /// Purchases a song and stores it persistently.
  Future<void> purchaseSong(String songFilename) async {
    List<String> purchased = await AppSettings.getPurchasedSongs();
    if (!purchased.contains(songFilename)) {
      purchased.add(songFilename);
      await AppSettings.savePurchasedSongs(purchased);
      purchasedSongs.value = purchased;
    }
  }

  /// Loads all settings from Hive.
  Future<void> _loadSettings() async {
    audioOn.value = await AppSettings.getAudioOn(defaultValue: true);
    soundsOn.value = await AppSettings.getSoundsOn(defaultValue: true);
    musicOn.value = await AppSettings.getMusicOn(defaultValue: true);
    playerName.value = await AppSettings.getPlayerName();
    purchasedSongs.value = await AppSettings.getPurchasedSongs();
    _log.fine(() => 'Loaded settings successfully.');
  }
}

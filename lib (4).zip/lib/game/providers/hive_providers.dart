import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/app_cache_service.dart';
import '../../core/services/app_settings.dart';
import '../../core/services/secure_storage.dart';

final appCacheServiceProvider = Provider<AppCacheService>((ref) {
  return AppCacheService();
});

final appSettingsProvider = Provider<AppSettings>((ref) {
  return AppSettings();
});

final secureStorageProvider = Provider<SecureStorage>((ref) {
  return SecureStorage();
});

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:trivia_tycoon/core/services/app_settings.dart';
import '../../../core/utils/hive_preferences.dart';
import '../models/confetti_settings.dart';

class ConfettiSettingsStorage {
  static const String _themePrefix = 'confetti_theme_';
  static const String _themesListKey = 'confetti_theme_names';

  /// Save a named confetti theme to Hive.
  static Future<void> saveTheme(String name, ConfettiSettings settings) async {
    final themeMap = settings.toMap();
    final jsonString = jsonEncode(themeMap);
    await HivePreferences.setString("$_themePrefix$name", jsonString);
    await _addThemeName(name);
  }

  /// Load a confetti theme by name from Hive.
  static Future<ConfettiSettings?> loadTheme(String name) async {
    final jsonString = await HivePreferences.getString("$_themePrefix$name");
    if (jsonString != null) {
      final map = jsonDecode(jsonString);

      // Migrate the old structure if needed
      final version = map['version'] ?? 1;
      final migrated = _migrate(map, version);

      return ConfettiSettings.fromMap(migrated);
    }
    try {
      final map = jsonDecode(jsonString!);
      final version = map['version'] ?? 1;
      final migrated = _migrate(map, version);
      return ConfettiSettings.fromMap(migrated);
    } catch (e) {
      debugPrint("Failed to load theme '$name': $e");
      return null;
    }
  }

  /// Migration logic
  static Map<String, dynamic> _migrate(Map<String, dynamic> map, int version) {
    if (version < 2) {
      map.putIfAbsent('useImages', () => true);
      map.putIfAbsent('gravity', () => 0.1);
      map.putIfAbsent('wind', () => 0.0);
      map['version'] = 2;
    }
    // Future versions can add more migrations here
    return map;
  }

  /// Load all saved themes
  static Future<List<ConfettiSettings>> loadAllThemes() async {
    final names = await getSavedThemeNames();
    final List<ConfettiSettings> themes = [];

    for (final name in names) {
      final theme = await loadTheme(name);
      if (theme != null) themes.add(theme);
    }

    return themes;
  }

  /// Get a list of all saved theme names.
  static Future<List<String>> getSavedThemeNames() async {
    return await AppSettings.getStringList(_themesListKey) ?? [];
  }

  /// Delete a saved confetti theme.
  static Future<void> deleteTheme(String name) async {
    await AppSettings.remove("$_themePrefix$name");
    final names = await getSavedThemeNames();
    names.remove(name);
    await AppSettings.setStringList(_themesListKey, names);
  }

  /// Reset all saved themes.
  static Future<void> clearAllThemes() async {
    final names = await getSavedThemeNames();
    for (final name in names) {
      await HivePreferences.remove("$_themePrefix$name");
    }
    await HivePreferences.remove(_themesListKey);
  }

  /// Add name to stored theme list
  static Future<void> _addThemeName(String name) async {
    final names = await AppSettings.getStringList(_themesListKey) ?? [];
    if (!names.contains(name)) {
      names.add(name);
      await AppSettings.setStringList(_themesListKey, names);
    }
  }

// Other utilities (deleteTheme, listThemes...) would go here
}

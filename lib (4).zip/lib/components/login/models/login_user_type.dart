enum LoginUserType {
  email,
  name,
  phone,
  firstName,
  lastName,
  text,
  intlPhone,
  checkbox
}
import 'dart:convert';
import 'package:encrypt/encrypt.dart' hide Fernet;
import 'package:fernet/fernet.dart' as f;
import 'package:trivia_tycoon/core/services/secure_storage.dart';

class FernetService {
  FernetService._();

  static Future<FernetService> initialize() async {
    // Load or generate Fernet key, validate, etc.
    return FernetService._();
  }

  /// Ensure a Fernet key is stored or generate one
  static Future<String> ensureFernetSecret() async {
    final box = await SecureStorage.getSecretBox();
    if (!box.containsKey('fernet_secret')) {
      final randomBytes = List<int>.generate(32, (_) => (DateTime.now().microsecond % 255));
      final base64Key = base64.encode(randomBytes);
      await box.put('fernet_secret', base64Key);
      return base64Key;
    }
    return box.get('fernet_secret');
  }

  /// Encrypt a string using Fernet
  static Future<String> encrypt(String plainText) async {
    final keyStr = await ensureFernetSecret();
    final key = Key.fromBase64(keyStr);
    final fernet = f.Fernet(key);
    final encrypted = fernet.encrypt(utf8.encode(plainText));
    return base64.encode(encrypted); // Store as base64 string
  }

  /// Decrypt a string using Fernet
  static Future<String> decrypt(String token) async {
    try {
      final keyStr = await ensureFernetSecret();
      final key = Key.fromBase64(keyStr);
      final fernet = f.Fernet(key);
      final decrypted = fernet.decrypt(base64.decode(token));
      return utf8.decode(decrypted);
    } catch (e) {
      return '❌ Fernet decryption failed: ${e.toString()}';
    }
  }
}

import 'dart:ui';
import 'dart:convert';
import 'package:hive_flutter/adapters.dart';
import '../../components/spin_wheel/models/prize_entry.dart';
import '../../game/controllers/theme_settings_controller.dart';
import '../../game/models/leaderboard_entry.dart';
import '../../game/models/question_model.dart';

class HivePreferences {
  static const _adminModeKey = 'admin_mode';
  static const _drawerThemeKey = 'drawer_theme';
  static const String _configBox = 'configBox';
  static const String _loggedInKey = 'isLoggedIn';
  static const _leaderboardKey = 'entries';
  static const _leaderboardBox = 'leaderboard_cache';
  static const String _userEmailKey = 'userEmail';
  static const String _settingsBox = 'settingsBox';
  static const String _questionCacheBox = 'question_cache';
  static const String _inventoryKey = 'purchased_items';
  static const String _themeSettingsBox = 'themeSettingsBox';
  static const String _depthCardThemeKey = 'depth_card_theme';
  static const String _themePresetsKey = 'custom_theme_presets';
  static const String _customThemesKey = 'custom_theme_presets';
  static const String _customSwatchesKey = 'custom_swatch_colors';
  static const String _defaultSwatchesKey = 'default_swatch_colors';

  static Future<void> init() async {
    await Hive.initFlutter(); // if using hive_flutter
    await Hive.openBox('settings');
    await Hive.openBox('theme_presets');
    await Hive.openBox('purchased_items');
    await Hive.openBox('store_data');
    await Hive.openBox('preferences');
    await Hive.openBox('configBox');
    await Hive.openBox('settingsBox');
  }

  /// Saves theme.
  static Future<void> setString(String key, String value) async {
    final box = await Hive.openBox('settings');
    await box.put(key, value);
  }

  /// Retrieves theme.
  static Future<String?> getString(String key) async {
    final box = await Hive.openBox('settings');
    return box.get(key) as String?;
  }

  /// Remove theme.
  static Future<void> remove(String key) async {
    final box = await Hive.openBox(_settingsBox);
    await box.delete(key);
  }









  static const String _onboardingKey = 'hasCompletedOnboarding';


}

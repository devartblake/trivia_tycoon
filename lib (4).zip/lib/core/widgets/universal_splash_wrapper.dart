import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:trivia_tycoon/screens/splash_variants/fortune_wheel_splash.dart';
import 'package:trivia_tycoon/screens/splash_variants/mind_market_splash.dart';
import 'package:trivia_tycoon/screens/splash_variants/vault_splash.dart';
import 'package:trivia_tycoon/screens/splash_variants/hq_terminal_splash.dart';
import 'package:trivia_tycoon/core/services/app_settings.dart';
import 'package:trivia_tycoon/core/services/splash_type.dart';

/// UniversalSplashWrapper wraps your app's startup experience
/// and shows the selected splash animation based on user or default setting.
class UniversalSplashWrapper extends ConsumerStatefulWidget {
  final VoidCallback onSplashFinished;

  const UniversalSplashWrapper({super.key, required this.onSplashFinished});

  @override
  ConsumerState<UniversalSplashWrapper> createState() => _UniversalSplashWrapperState();
}

class _UniversalSplashWrapperState extends ConsumerState<UniversalSplashWrapper> {
  late SplashType splashType;

  @override
  Future<void> initState() async {
    super.initState();
    splashType = await AppSettings.getSplashType();
  }

  @override
  Widget build(BuildContext context) {
    switch (splashType) {
      case SplashType.fortuneWheel:
        return FortuneWheelSplash(onStart: widget.onSplashFinished);
      case SplashType.mindMarket:
        return MindMarketSplash();
      case SplashType.vaultUnlock:
        return VaultSplash();
      case SplashType.hqTerminal:
        return HqTerminalSplash();
      case SplashType.empireRising:
        return VaultSplash(); // Placeholder
    }
  }
}

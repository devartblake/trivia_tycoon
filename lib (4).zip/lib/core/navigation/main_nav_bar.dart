import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:trivia_tycoon/screens/menu/main_menu_screen.dart';
import 'package:trivia_tycoon/screens/quiz/question_screen.dart';
import 'package:trivia_tycoon/screens/store/store_screen.dart';
import 'package:trivia_tycoon/screens/leaderboard/leaderboard_screen.dart';
import 'package:trivia_tycoon/screens/settings/settings_screen.dart';
import 'package:trivia_tycoon/components/navigation/fluid_nav_bar.dart';
import 'package:trivia_tycoon/components/navigation/fluid_nav_bar_icon.dart';
import 'package:trivia_tycoon/components/navigation/fluid_nav_bar_style.dart';

class MainNavBar extends StatefulWidget {
  const MainNavBar({super.key});

  @override
  State<MainNavBar> createState() => _MainNavBarState();
}

class _MainNavBarState extends State<MainNavBar> {
  int _selectedIndex = 0;

  final List<String> _routes = [
    '/',
    '/quiz',
    '/store',
    '/leaderboard',
    '/settings',
  ];

  void _onNavBarItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    GoRouter.of(context).go(_routes[index]);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        FluidNavBar(
          body: IndexedStack(
            index: _selectedIndex,
            children: const [
              MainMenuScreen(),
              QuestionScreen(),
              StoreScreen(),
              LeaderboardScreen(),
              SettingsScreen(),
            ],
          ),
          icons: [
            FluidNavBarIcon(icon: Icons.home, extras: {"label": "Home"}),
            FluidNavBarIcon(icon: Icons.quiz, extras: {"label": "Quiz"}),
            FluidNavBarIcon(icon: Icons.store, extras: {"label": "Store"}),
            FluidNavBarIcon(
              icon: Icons.leaderboard,
              extras: {"label": "Leaderboard"},
            ),
            FluidNavBarIcon(
              icon: Icons.settings,
              extras: {"label": "Settings"},
            ),
          ],
          onChange: _onNavBarItemTapped,
          style: FluidNavBarStyle(
            barBackgroundColor: Theme.of(context).primaryColor,
            iconSelectedForegroundColor: Colors.white,
            iconUnselectedForegroundColor: Colors.black54,
          ),
          scaleFactor: 1.5,
          defaultIndex: _selectedIndex,
          itemBuilder:
              (icon, item) =>
                  Semantics(label: icon.extras!["label"], child: item),
        ),
      ],
    );
  }
}

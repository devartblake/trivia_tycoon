import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:trivia_tycoon/core/services/config_service.dart';
import 'package:trivia_tycoon/core/services/theme_notifier.dart';
import 'package:trivia_tycoon/core/utils/hive_preferences.dart';
import 'package:trivia_tycoon/core/manager/service_manager.dart';

/// AppInit handles bootstrapping critical services before runApp()
class AppInit {
  static Future<(ServiceManager, ThemeNotifier)> initialize() async {
    WidgetsFlutterBinding.ensureInitialized();
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

    // Local database (Hive)
    await Hive.initFlutter();
    await HivePreferences.init();

    // Load and initialize ServiceManager
    final serviceManager = await ServiceManager.initialize();

    // Inject dependencies into ConfigService
    final configService = ConfigService.instance;
    configService.initServices(serviceManager);

    // Load local + remote config
    await configService.loadConfig().timeout(
      const Duration(seconds: 10),
      onTimeout: () {
        debugPrint("[WARN] ConfigService timeout. Using default settings.");
      },
    );

    // Initialize theme notifier
    final themeNotifier = ThemeNotifier();
    await themeNotifier.initializationCompleted;

    return (serviceManager, themeNotifier);
  }
}
import 'package:trivia_tycoon/components/qr_code/services/qr_history_service.dart';
import 'package:trivia_tycoon/core/services/app_cache_service.dart';
import 'package:trivia_tycoon/core/services/app_settings.dart';
import 'package:trivia_tycoon/core/services/secure_storage.dart';
import 'package:trivia_tycoon/core/services/swatch_service.dart';
import 'package:trivia_tycoon/core/services/api_service.dart';
import 'package:trivia_tycoon/core/services/encryption_service.dart';
import 'package:trivia_tycoon/core/services/fernet_service.dart';
import 'package:trivia_tycoon/core/services/leaderboard_data_service.dart';
import 'package:trivia_tycoon/core/services/store_service.dart';
import 'package:trivia_tycoon/game/analytics/services/analytics_service.dart';
import 'package:trivia_tycoon/game/services/mission_service.dart';

class ServiceManager {
  static late final ServiceManager instance;

  final ApiService apiService;
  final AnalyticsService analyticsService;
  final LeaderboardDataService leaderboardDataService;
  final StoreService storeService;
  final EncryptionService encryptionService;
  final FernetService fernetService;
  final SwatchService swatchService;
  final AppSettings appSettings;
  final AppCacheService appCacheService;
  final SecureStorage secureStorage;
  final QrHistoryService historyService;
  final MissionService missionService;

  ServiceManager({
    required this.apiService,
    required this.analyticsService,
    required this.leaderboardDataService,
    required this.storeService,
    required this.encryptionService,
    required this.fernetService,
    required this.swatchService,
    required this.appSettings,
    required this.appCacheService,
    required this.secureStorage,
    required this.historyService,
    required this.missionService,
  });

  /// Initialize all core services and return a ready ServiceManager
  static Future<ServiceManager> initialize() async {
    final api = ApiService(baseUrl: 'https://api.url');
    final leaderboard = LeaderboardDataService(apiService: api);

    // Add async initialize methods
    final store = await StoreService.initialize(api);
    final encrypt = await EncryptionService.initialize();
    final fernet = await FernetService.initialize();
    final cache = await AppCacheService.initialize();
    final settings = await AppSettings.initialize();
    final swatch = SwatchService();
    final secrets = SecureStorage();
    final mission = MissionService();
    final analytics = AnalyticsService(api);
    final history = QrHistoryService(cache: cache, settings: settings);

    // Save it globally here
    return ServiceManager(
      apiService: api,
      analyticsService: analytics,
      leaderboardDataService: leaderboard,
      storeService: store,
      encryptionService: encrypt,
      fernetService: fernet,
      swatchService: swatch,
      appSettings: settings,
      appCacheService: cache,
      secureStorage: secrets,
      historyService: history,
      missionService: mission,
    );
  }
}

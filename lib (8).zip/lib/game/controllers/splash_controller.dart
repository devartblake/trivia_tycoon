import 'package:trivia_tycoon/core/services/settings/app_settings.dart';
import '../../ui_components/login/providers/auth.dart';

class SplashController {
  /// Determines the appropriate route based on login and onboarding status.
  static Future<String> initAppFlow() async {
    final isLoggedIn = await AuthService.isLoggedIn();
    final hasOnboarded = await AppSettings.hasCompletedOnboarding();

    if (!isLoggedIn) {
      return '/login';
    } else if (!hasOnboarded) {
      return '/onboarding';
    } else {
      return '/';
    }
  }

  /// Legacy fallback if needed elsewhere
  static Future<String> getInitialRoute() => initAppFlow();
}

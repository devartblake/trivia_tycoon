import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:trivia_tycoon/core/services/settings/splash_settings_service.dart';
import 'package:trivia_tycoon/screens/splash_variants/fortune_wheel_splash.dart';
import 'package:trivia_tycoon/screens/splash_variants/mind_market_splash.dart';
import 'package:trivia_tycoon/screens/splash_variants/vault_splash.dart';
import 'package:trivia_tycoon/screens/splash_variants/hq_terminal_splash.dart';
import 'package:trivia_tycoon/core/services/navigation/splash_type.dart';

/// UniversalSplashWrapper wraps your app's startup experience
/// and shows the selected splash animation based on user or default setting.
class UniversalSplashWrapper extends ConsumerStatefulWidget {
  final VoidCallback onSplashFinished;

  const UniversalSplashWrapper({super.key, required this.onSplashFinished});

  @override
  ConsumerState<UniversalSplashWrapper> createState() => _UniversalSplashWrapperState();
}

class _UniversalSplashWrapperState extends ConsumerState<UniversalSplashWrapper> {
  late Future<SplashType> _splashTypeFuture;

  @override
  initState() {
    super.initState();
    setState(() {
      _splashTypeFuture = SplashSettingsService().getSplashType();
    });
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<SplashType>(
      future: _splashTypeFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            backgroundColor: Colors.black,
            body: Center(child: CircularProgressIndicator(color: Colors.amber)),
          );
        }

        final splashType = snapshot.data ?? SplashType.mindMarket;

        switch (splashType) {
          case SplashType.fortuneWheel:
            return FortuneWheelSplash(onStart: widget.onSplashFinished);
          case SplashType.mindMarket:
            return MindMarketSplash(onStart: widget.onSplashFinished);
          case SplashType.vaultUnlock:
            return VaultSplash(onStart: widget.onSplashFinished);
          case SplashType.hqTerminal:
            return HqTerminalSplash(onStart: widget.onSplashFinished);
          case SplashType.empireRising:
            return VaultSplash(onStart: widget.onSplashFinished); // Placeholder
        }
      },
    );
  }
}

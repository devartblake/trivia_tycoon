import 'package:flutter/material.dart';

class QuestionDetailsScreen extends StatelessWidget {
  const QuestionDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Question details")),
      body: const Center(child: Text("Question details screen coming soon!")),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:trivia_tycoon/core/services/config_service.dart';
import 'package:trivia_tycoon/core/utils/theme_mapper.dart';
import 'package:trivia_tycoon/game/controllers/riverpod_providers.dart' as providers;
import 'package:trivia_tycoon/components/power_ups/power_up_HUD_Overlay.dart';

import '../../core/theme/app_scroll_behavior.dart';
import '../../core/widgets/loading_screen.dart';
import '../../core/widgets/offline_fallback_screen.dart';
import '../../core/widgets/universal_splash_wrapper.dart';

/// AppShell is the main scaffold wrapper for the app
class AppShell extends ConsumerWidget {
  const AppShell({super.key});

  /// Optionally, expose static app metadata if needed globally
  static String? get pkg => ConfigService.getPackage("trivia_tycoon");
  static String? get bundle => ConfigService.getBundle("trivia_tycoon");

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final routerAsync = ref.watch(providers.routerProvider);
    final ageGroup = ref.watch(providers.userAgeGroupProvider);
    final themeSettings = ref.watch(providers.themeSettingsProvider);
    final appTheme = ThemeMapper.getThemeForAgeGroup(ageGroup);

    return routerAsync.when(
      data: (router) => AnimatedSwitcher(
        duration: const Duration(milliseconds: 400),
        switchInCurve: Curves.easeIn,
        switchOutCurve: Curves.easeOut,
        child: MaterialApp.router(
          key: ValueKey(
              "${themeSettings.primaryColor.value}-${themeSettings.brightness.name}"
          ),
          debugShowCheckedModeBanner: false,
          scrollBehavior: AppScrollBehavior(),
          title: 'Trivia Tycoon',
          theme: ThemeData(
            brightness: themeSettings.brightness,
            primaryColor: themeSettings.primaryColor,
            colorScheme: ColorScheme.fromSeed(
              seedColor: themeSettings.primaryColor,
              brightness: themeSettings.brightness,
            ),
            useMaterial3: true,
          ),
          routerConfig: router,
          builder: (context, child) => AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child:  Stack(
              children: [
                if (child != null) child,
                const PowerUpHUDOverlay(),
              ],
            ),
          ),
        ),
      ),
      loading: () => UniversalSplashWrapper(
        onSplashFinished: () => ref.invalidate(providers.routerProvider),
      ),
      error: (err, _) => OfflineFallbackScreen(
        errorMessage: "Router failed to load.",
        onRetry: () => ref.invalidate(providers.routerProvider),
      ),
    );
  }
}

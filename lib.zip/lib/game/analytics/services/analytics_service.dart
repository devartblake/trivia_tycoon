import 'package:trivia_tycoon/game/controllers/riverpod_providers.dart';

import '../../../core/manager/service_manager.dart';
import '../../../core/services/api_service.dart';
import '../models/engagement_entry.dart';
import '../models/mission_analytics_entry.dart';
import '../models/retention_entry.dart';

/// Handles fetching analytics data from the API or local storage.
class AnalyticsService {
  final ApiService apiService;
  AnalyticsService(this.apiService);

  /// Fetches mock mission analytics data
  Future<List<MissionAnalyticsEntry>> fetchMissionAnalytics() async {
    final jsonData = await apiService.getMockData('mock_mission_analytics.json');
    return (jsonData as List<dynamic>)
        .map((e) => MissionAnalyticsEntry.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  /// Fetches mock user engagement analytics data
  Future<List<EngagementEntry>> fetchEngagementAnalytics() async {
    final jsonData = await apiService.getMockData('mock_engagement_analytics.json');
    return (jsonData as List<dynamic>)
        .map((e) => EngagementEntry.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  /// Fetches mock user retention analytics data
  Future<List<RetentionEntry>> fetchRetentionAnalytics() async {
    final jsonData = await apiService.getMockData('mock_retention_analytics.json');
    return (jsonData as List<dynamic>)
        .map((e) => RetentionEntry.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}

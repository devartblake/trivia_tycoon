import 'package:flutter/material.dart';
import '../../core/services/storage/app_settings.dart';
import '../../game/controllers/settings_controller.dart';
import '../../audio/models/songs.dart';

enum MusicFilter { all, purchased, exclusive }

class MusicScreen extends StatefulWidget {
  const MusicScreen({super.key});

  @override
  State<MusicScreen> createState() => _MusicScreenState();
}

class _MusicScreenState extends State<MusicScreen> {
  late final SettingsController settingsController;

  MusicFilter _selectedFilter = MusicFilter.all;
  List<String> _purchasedSongs = [];

  @override
  void initState() {
    super.initState();
    settingsController = SettingsController();
    _loadPurchasedSongs();
  }

  Future<void> _loadPurchasedSongs() async {
    final purchased = await AppSettings.getPurchasedSongs();
    setState(() {
      _purchasedSongs = purchased;
    });
  }

  Future<void> _purchaseSong(Song song) async {
    await AppSettings.purchaseSong(song.filename);
    await _loadPurchasedSongs();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${song.name} purchased successfully!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final exclusiveSongs = songs.where((song) => song.isExclusive).toSet();
    final purchasedSet =
        songs.where((song) => _purchasedSongs.contains(song.filename)).toSet();

    Set<Song> displayedSongs;
    switch (_selectedFilter) {
      case MusicFilter.purchased:
        displayedSongs = purchasedSet;
        break;
      case MusicFilter.exclusive:
        displayedSongs = exclusiveSongs;
        break;
      default:
        displayedSongs = songs;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Music Library')),
      body: Column(
        children: [
          // Filter toggle buttons
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 8.0,
              vertical: 10.0,
            ),
            child: ToggleButtons(
              isSelected: [
                _selectedFilter == MusicFilter.all,
                _selectedFilter == MusicFilter.purchased,
                _selectedFilter == MusicFilter.exclusive,
              ],
              onPressed: (index) {
                setState(() {
                  _selectedFilter = MusicFilter.values[index];
                });
              },
              borderRadius: BorderRadius.circular(10),
              children: const [
                Padding(padding: EdgeInsets.all(8.0), child: Text('All Songs')),
                Padding(padding: EdgeInsets.all(8.0), child: Text('Purchased')),
                Padding(padding: EdgeInsets.all(8.0), child: Text('Exclusive')),
              ],
            ),
          ),

          // Songs list area
          Expanded(
            child: FutureBuilder<List<String>>(
              future: AppSettings.getPurchasedSongs(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final purchasedSongs = snapshot.data ?? [];

                return ListView.builder(
                  itemCount: displayedSongs.length,
                  itemBuilder: (context, index) {
                    final song = displayedSongs.elementAt(index);
                    final isPurchased = purchasedSongs.contains(song.filename);

                    return ListTile(
                      leading: Icon(
                        isPurchased ? Icons.music_note : Icons.lock,
                        color: isPurchased ? Colors.green : Colors.grey,
                      ),
                      title: Text(song.name),
                      subtitle: Text(song.artist ?? 'Unknown Artist'),
                      trailing:
                          isPurchased
                              ? const Icon(Icons.play_arrow)
                              : ElevatedButton(
                                onPressed: () => _purchaseSong(song),
                                child: const Text('Buy'),
                              ),
                      onTap:
                          isPurchased
                              ? () {
                                // TODO: Implement song playback logic
                              }
                              : null,
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

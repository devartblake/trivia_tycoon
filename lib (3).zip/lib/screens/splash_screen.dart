import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../game/controllers/splash_controller.dart';
import '../core/services/storage/app_settings.dart';
import '../core/services/navigation/splash_type.dart';
import '../screens/splash_variants/mind_market_splash.dart';
import '../screens/splash_variants/vault_splash.dart';
import '../screens/splash_variants/fortune_wheel_splash.dart';
import '../screens/splash_variants/hq_terminal_splash.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  SplashScreenState createState() => SplashScreenState();
}

class SplashScreenState extends State<SplashScreen> {
  final SplashController controller = SplashController();
  SplashType splashType = SplashType.mindMarket;

  @override
  void initState() {
    super.initState();
    _loadSplashType();
    _navigateAfterDelay();
  }

  Future<void> _loadSplashType() async {
    final type = await AppSettings.getSplashType();
    if (mounted) {
      setState(() => splashType = type);
    }
  }

  Future<void> _navigateAfterDelay() async {
    await Future.delayed(const Duration(seconds: 2)); // Splash delay
    final route = await SplashController.getInitialRoute();

    if (!mounted) return;
      context.go(route);
  }

  void defaultStartHandler() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Splash start triggered")),
    );
  }

  Widget _buildSplashBackground() {
    switch (splashType) {
      case SplashType.mindMarket:
        return const MindMarketSplash();
      case SplashType.vaultUnlock:
        return const VaultSplash();
      case SplashType.fortuneWheel:
        return FortuneWheelSplash(onStart: defaultStartHandler,);
      case SplashType.hqTerminal:
        return const HqTerminalSplash();
      case SplashType.empireRising:
        return const MindMarketSplash(); // Placeholder
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _buildSplashBackground(),
          //const TriviaSplashOverlay(),
        ],
      ),
    );
  }
}

import 'package:flutter/cupertino.dart';

class SpinEarnScreen extends StatelessWidget {
  const SpinEarnScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}
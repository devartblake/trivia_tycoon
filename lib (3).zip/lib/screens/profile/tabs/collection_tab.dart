import 'package:flutter/material.dart';

class CollectionTab extends StatelessWidget {
  const CollectionTab({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: Text('Collections Screen')));
}
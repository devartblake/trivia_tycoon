import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:trivia_tycoon/core/services/storage/app_settings.dart';
import '../../game/controllers/onboarding_controller.dart';
import '../../game/models/onboarding_step.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  late final OnboardingController _controller;

  // Store form values across steps
  final Map<String, dynamic> _userData = {};

  @override
  void initState() {
    super.initState();
    _controller = OnboardingController(context);
  }

  /// Called when a step (form, avatar picker, etc.) submits data
  void _onUserDataChanged(Map<String, dynamic> newData) {
    setState(() {
      _userData.addAll(newData); // merge new values into existing map
    });
  }

  /// Called by the final onboarding step to save and navigate
  Future<void> _onFinalStepComplete() async {
    // Save to persistent storage
    await AppSettings.setHasCompletedOnboarding(true);
    await AppSettings.setString('username', _userData['username'] ?? '');
    await AppSettings.setString('name', _userData['name'] ?? '');
    await AppSettings.setString('country', _userData['country'] ?? '');
    await AppSettings.setString('ageGroup', _userData['ageGroup'] ?? '');
    await AppSettings.setString('avatar', _userData['avatar'] ?? '');

    // Controller handles navigation
    _controller.completeOnboarding();
  }

  @override
  Widget build(BuildContext context) {
    // Generate steps and inject callbacks
    final steps = OnboardingStep.defaultSteps(
      controller: _controller, // ✅ inject controller
      onUserDataChanged: _onUserDataChanged,
      onFinalStepComplete: _onFinalStepComplete,
    );

    return Scaffold(
      appBar: AppBar(
        backgroundColor: _controller.getBackgroundColor(),
        elevation: 0,
        actions: [
          if (_controller.currentIndex < steps.length - 1)
            TextButton(
              onPressed: () async {
                await AppSettings.setHasCompletedOnboarding(true);
                if (context.mounted) context.go('/');
              },
              child: const Text("Skip", style: TextStyle(color: Colors.blue),),
            )
        ],
      ),
      body: PageView.builder(
        controller: _controller.pageController,
        itemCount: steps.length,
        onPageChanged: _controller.onPageChanged,
        physics: const NeverScrollableScrollPhysics(),
        itemBuilder: (context, index) => steps[index].widget,
      ),
    );
  }
}

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:trivia_tycoon/core/services/storage/app_settings.dart';

final coinBalanceProvider = StateNotifierProvider<CoinBalanceNotifier, int>((
  ref,
) {
  return CoinBalanceNotifier();
});

class CoinBalanceNotifier extends StateNotifier<int> {
  static const _key = 'coinBalance';
  CoinBalanceNotifier() : super(0) {
    _loadFromHive();
  }

  Future<void> _loadFromHive() async {
    final stored = await AppSettings.getInt(_key) ?? 0;
    state = stored;
  }

  Future<void> add(int amount) async {
    state += amount;
    await AppSettings.setInt(_key, state);
  }

  Future<void> deduct(int amount) async {
    if (state >= amount) {
      state -= amount;
      await AppSettings.setInt(_key, state);
    }
  }

  bool canAfford(int amount) => state >= amount;

  Future<void> set(int amount) async {
    state = amount;
    await AppSettings.setInt(_key, state);
  }

  Future<void> reset() => set(0);
}

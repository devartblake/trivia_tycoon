import 'package:flutter/material.dart';
import 'package:trivia_tycoon/core/bootstrap/app_init.dart';
import 'package:trivia_tycoon/core/bootstrap/app_launcher.dart';
import 'package:trivia_tycoon/core/widgets/offline_fallback_screen.dart';
import 'core/manager/service_manager.dart';
import 'core/services/theme/theme_notifier.dart';
import 'core/widgets/universal_splash_wrapper.dart';

void main() {
  runApp(const TriviaTycoonApp());
}

class TriviaTycoonApp extends StatelessWidget {
  const TriviaTycoonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<(ServiceManager, ThemeNotifier)>(
        future: AppInit.initialize(),
        builder: (context, snapshot) {

          return Directionality(
              textDirection: TextDirection.ltr,
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 500),
                switchInCurve: Curves.easeIn,
                switchOutCurve: Curves.easeOut,
                child: _buildContent(snapshot),
              )
          );
        }
      );
    }

  Widget _buildContent(AsyncSnapshot<(ServiceManager, ThemeNotifier)> snapshot) {
    // Step 1: Still initializing → show animated splash
    if (snapshot.connectionState == ConnectionState.waiting) {
      return UniversalSplashWrapper(onSplashFinished: () => runApp(const TriviaTycoonApp()));
    }

    // Step 2: Failed to load → show offline fallback UI
    if (snapshot.hasError || !snapshot.hasData) {
      return OfflineFallbackScreen(
        onRetry: () {
          runApp(const TriviaTycoonApp());
        }
      );
    }

    // Step 3: All good → Launch actual app
    return AppLauncher(initialData: snapshot.data!);
  }
}

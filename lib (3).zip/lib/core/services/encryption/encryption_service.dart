import 'dart:typed_data';
import 'package:trivia_tycoon/core/utils/encryption_utils.dart';
import 'package:trivia_tycoon/core/utils/hive_preferences.dart';
import 'fernet_service.dart';

class EncryptionService {
  // Add any secret or config setup here
  EncryptionService._();

  static Future<EncryptionService> initialize() async {
    // Load encryption keys, initialize secure storage, etc.
    return EncryptionService._();
  }

  /// Encrypt using AES (default app key)
  String encryptAES(String text) => EncryptionUtils.encryptAES(text);

  String decryptAES(String text) => EncryptionUtils.decryptAES(text);

  /// Encrypt/decrypt files
  Uint8List encryptFile(Uint8List data) => EncryptionUtils.encryptFileBytes(data);

  Uint8List decryptFile(Uint8List data) => EncryptionUtils.decryptFileBytes(data);

  /// Fernet support
  Future<String> encryptFernet(String plain) async => await FernetService.encrypt(plain);

  Future<String> decryptFernet(String token) async => await FernetService.decrypt(token);

  /// AES using passphrase-derived key
  String encryptWithPassphrase(String text, String passphrase, String salt) {
    final key = EncryptionUtils.deriveKeyFromPassword(passphrase, salt);
    return EncryptionUtils.encryptAES(text, customKey: key);
  }

  String decryptWithPassphrase(String encryptedText, String passphrase, String salt) {
    final key = EncryptionUtils.deriveKeyFromPassword(passphrase, salt);
    return EncryptionUtils.decryptAES(encryptedText, customKey: key);
  }

  /// Wipe any saved Fernet key (for logout or reset)
  Future<void> clearFernetKey() async => HivePreferences.remove('fernet_secret');
}

import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:trivia_tycoon/game/controllers/settings_controller.dart';

// 🔧 Core Services & Config
import '../../components/qr_code/models/qr_settings_model.dart';
import '../../components/qr_code/services/qr_history_service.dart';
import '../../core/manager/service_manager.dart';
import '../../core/navigation/app_router.dart';
import '../../core/services/api_service.dart';
import '../../core/services/app_settings.dart';
import '../../core/services/analytics/config_service.dart';
import '../../core/services/leaderboard_data_service.dart';
import '../../core/services/question/question_service.dart';
import '../../core/services/secure_storage.dart';
import '../../core/services/swatch_service.dart';
import '../../core/services/app_cache_service.dart';

// 📦 Store & Inventory
import '../../core/services/theme/theme_notifier.dart';
import '../analytics/services/analytics_service.dart';
import '../models/leaderboard_entry.dart';
import '../models/store_item_model.dart';
import '../services/achievement_service.dart';
import '../services/store_data_service.dart';

// 🧠 Game State & Controllers
import '../controllers/question_controller.dart';
import '../controllers/theme_settings_controller.dart';
import '../controllers/leaderboard_controller.dart';
import '../controllers/profile_avatar_controller.dart';
import '../state/qr_settings_state.dart';
import '../state/question_state.dart';

// 🎊 Visual/Confetti
import '../../components/confetti/core/confetti_controller.dart';

// 🎡 Spin Wheel
import '../../components/spin_wheel/controllers/spining_controller.dart';
import '../../components/spin_wheel/services/segment_loader.dart';

// 💰 Currency
import '../../core/manager/currency_manager.dart';
import '../models/currency_type.dart';

// 🎖️ Badges
import '../models/badge.dart';

// --- 🌍 Global Services ---
final configServiceProvider = Provider<ConfigService>((ref) => ConfigService.instance);

/// Holds the [ServiceManager] after initialization
///
/// Must be overridden in `AppLauncher` after [AppInit] completes.
final serviceManagerProvider = Provider<ServiceManager>((ref) {
  throw UnimplementedError(
    "serviceManagerProvider must be overridden in ProviderScope in AppLauncher",
  );
});

/// Provides the GoRouter instance reactively
final routerProvider = FutureProvider<GoRouter>((ref) async {
  return await AppRouter.router();
});

final apiServiceProvider = Provider<ApiService>((ref) {
  final config = ref.watch(configServiceProvider);
  return ApiService(baseUrl: config.apiBaseUrl);
});

// --- 🧠 Game Logic ---
/// Provides the SettingsController for theme/audio/etc
final settingsControllerProvider = Provider<SettingsController>((ref) {
  return ref.read(serviceManagerProvider).settingsController;
});

/// Provides the AchievementService from ServiceManager
final achievementServiceProvider = Provider<AchievementService>((ref) {
  return ref.read(serviceManagerProvider).achievementService;
});

final questionControllerProvider = StateNotifierProvider<QuestionController, QuestionState>((ref) {
  return QuestionController(ref: ref);
});

/// Provides the singleton QuestionService instance
final questionServiceProvider = Provider<QuestionService>((ref) {
  return ref.read(serviceManagerProvider).questionService;
});

final leaderboardControllerProvider = ChangeNotifierProvider<LeaderboardController>((ref) {
  final leaderboardDataService = ref.watch(leaderboardDataServiceProvider);
  return LeaderboardController(dataService: leaderboardDataService, ref: ref);
});

final leaderboardDataServiceProvider = Provider<LeaderboardDataService>((ref) {
  final api = ref.watch(apiServiceProvider);
  assetLoader() => ref.watch(leaderboardAssetProvider.future);
  return LeaderboardDataService(apiService: api, assetLoader: assetLoader);
});

/// Loads leaderboard.json from assets/data
final leaderboardAssetProvider = FutureProvider<List<LeaderboardEntry>>((ref) async {
  final jsonStr = await rootBundle.loadString('assets/data/leaderboard/leaderboard.json');
  final List<dynamic> decoded = json.decode(jsonStr);
  return decoded.map((e) => LeaderboardEntry.fromJson(e)).toList();
});

final profileAvatarControllerProvider = ChangeNotifierProvider<ProfileAvatarController>(
      (ref) => ProfileAvatarController(),
);

// --- 🎨 Theme & Visual Settings ---
final userAgeGroupProvider = StateProvider<String>((ref) => 'teens');

final themeSettingsProvider = StateNotifierProvider<ThemeSettingsController, ThemeSettings>(
      (ref) => ThemeSettingsController(),
);

/// This provider must be overridden at app launch via AppLauncher
final themeNotifierProvider = Provider<ThemeNotifier>((ref) {
  throw UnimplementedError('ThemeNotifier must be overridden in AppLauncher');
});

final swatchServiceProvider = Provider<SwatchService>((ref) {
  return ref.read(serviceManagerProvider).swatchService;
});

// --- 🎊 Confetti System ---
final confettiControllerProvider = ChangeNotifierProvider<ConfettiController>((ref) {
  return ConfettiController();
});

// --- 💽 Local Storage Services ---
final appSettingsProvider = Provider<AppSettings>((ref) {
  return ref.read(serviceManagerProvider).appSettings;
});

final appCacheServiceProvider = Provider<AppCacheService>((ref) {
  return ref.read(serviceManagerProvider).appCacheService;
});

final secureStorageProvider = Provider<SecureStorage>((ref) {
  return ref.read(serviceManagerProvider).secureStorage;
});

final qrHistoryServiceProvider = Provider<QrHistoryService>((ref) {
  final cache = ref.read(serviceManagerProvider).appCacheService;
  final  settings = ref.read(serviceManagerProvider).appSettings;
  return QrHistoryService(cache: cache, settings: settings);
});

final qrSettingsProvider = StateNotifierProvider<QrSettingsNotifier, QrSettingsModel>(
      (ref) => QrSettingsNotifier(),
);

// --- 🛍 Store & Inventory ---
final storeServiceProvider = Provider((ref) => ref.read(serviceManagerProvider).storeService);

final storeItemsProvider = FutureProvider<List<StoreItemModel>>((ref) async {
  final jsonString = await rootBundle.loadString('assets/data/store_items.json');
  final List<dynamic> jsonData = jsonDecode(jsonString);
  return jsonData.map((e) => StoreItemModel.fromJson(e)).toList();
});

final powerUpInventoryProvider = FutureProvider<List<StoreItemModel>>((ref) async {
  final ids = await ref.read(appSettingsProvider).getAllPurchasedItems();
  final all = await StoreDataService.loadStoreItems();
  return all.where((item) => ids.contains(item.id) && item.category == 'power-up').toList();
});

// --- 🔒 Encryption ---
final encryptionServiceProvider = Provider((ref) => ref.read(serviceManagerProvider).encryptionService);

// --- 💰 Currency ---
final currencyManagerProvider = Provider<CurrencyManager>((ref) => CurrencyManager(ref));

final coinBalanceProvider = Provider<int>((ref) {
  return ref.watch(currencyManagerProvider).getBalance(CurrencyType.coins);
});

final diamondBalanceProvider = Provider<int>((ref) {
  return ref.watch(currencyManagerProvider).getBalance(CurrencyType.diamonds);
});

final coinNotifierProvider = Provider<CurrencyNotifier>((ref) {
  return ref.read(currencyManagerProvider).getNotifier(CurrencyType.coins);
});

final diamondNotifierProvider = Provider<CurrencyNotifier>((ref) {
  return ref.read(currencyManagerProvider).getNotifier(CurrencyType.diamonds);
});

// --- 🎡 Spin Wheel ---
final segmentLoaderProvider = Provider<SegmentLoader>((ref) {
  return SegmentLoader(
    source: SegmentSource.remote,
    remoteUrl: 'https://example.com/api/segments',
  );
});

final spinningControllerProvider = ChangeNotifierProvider<SpinningController>((ref) {
  return SpinningController(ref);
});

// --- 🎖 Badges ---
final badgeProvider = FutureProvider<List<GameBadge>>((ref) async {
  final jsonString = await rootBundle.loadString('assets/data/badges_icons.json');
  final List<dynamic> jsonData = json.decode(jsonString);
  return jsonData.map((e) => GameBadge.fromJson(e)).toList();
});

// --- Analytics ---
/// Access to AnalyticsService from the ServiceManager
final analyticsServiceProvider = Provider<AnalyticsService>((ref) {
  final serviceManager = ref.watch(serviceManagerProvider);
  return serviceManager.analyticsService;
});
import 'package:flutter/material.dart';

class HqTerminalSplash extends StatelessWidget {
  const HqTerminalSplash({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Text("[BOOTING TRIVIA MAINFRAME]",
                style: TextStyle(color: Colors.greenAccent, fontFamily: 'Courier')),
            SizedBox(height: 8),
            Text("[CALIBRATING CURIOSITY ENGINE...]",
                style: TextStyle(color: Colors.greenAccent, fontFamily: 'Courier')),
            SizedBox(height: 8),
            Text("[STATUS: READY]",
                style: TextStyle(color: Colors.greenAccent, fontFamily: 'Courier')),
          ],
        ),
      ),
    );
  }
}

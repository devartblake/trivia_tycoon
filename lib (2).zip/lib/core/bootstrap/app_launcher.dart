import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:trivia_tycoon/core/services/analytics/app_lifecycle.dart';
import 'package:trivia_tycoon/core/manager/service_manager.dart';
import 'package:trivia_tycoon/core/services/analytics/config_service.dart';
import 'package:trivia_tycoon/core/services/theme/theme_notifier.dart';
import 'package:trivia_tycoon/game/controllers/riverpod_providers.dart' as providers;
import 'package:trivia_tycoon/screens/app_shell/app_shell.dart';

/// AppLauncher handles config + service initialization and launches the app
class AppLauncher extends StatelessWidget {
  final (ServiceManager, ThemeNotifier) initialData;
  const AppLauncher({super.key, required this.initialData});

  @override
  Widget build(BuildContext context) {
    final (serviceManager, themeNotifier) = initialData;

    return ProviderScope(
      overrides: [
        providers.serviceManagerProvider.overrideWithValue(serviceManager),
        providers.configServiceProvider.overrideWithValue(ConfigService.instance),
        providers.themeNotifierProvider.overrideWithValue(themeNotifier),
      ],
      child: const AppLifecycleObserver(
        child: AppShell(),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:trivia_tycoon/core/services/analytics/app_lifecycle.dart';
import 'package:trivia_tycoon/core/manager/service_manager.dart';
import 'package:trivia_tycoon/core/services/analytics/config_service.dart';
import 'package:trivia_tycoon/core/services/theme/theme_notifier.dart';
import 'package:trivia_tycoon/game/providers/riverpod_providers.dart' as providers;
import 'package:trivia_tycoon/screens/app_shell/app_shell.dart';
import 'package:go_router/go_router.dart';

/// AppLauncher handles config + service initialization and launches the app
class AppLauncher extends ConsumerStatefulWidget {
  final (ServiceManager, ThemeNotifier) initialData;
  const AppLauncher({super.key, required this.initialData});

  @override
  ConsumerState<AppLauncher> createState() => _AppLauncherState();
}

class _AppLauncherState extends ConsumerState<AppLauncher> {
  GoRouter? _router;

  @override
  void initState() {
    super.initState();
    _initRouter();
  }

  Future<void> _initRouter() async {
    final container = ProviderContainer(overrides: [
      providers.serviceManagerProvider.overrideWithValue(widget.initialData.$1),
      providers.configServiceProvider.overrideWithValue(ConfigService.instance),
      providers.themeNotifierProvider.overrideWithValue(widget.initialData.$2),
    ]);
    final router = await container.read(providers.routerProvider.future);
    setState(() => _router = router);
  }

  @override
  Widget build(BuildContext context) {
    if (_router == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return ProviderScope(
      overrides: [
        providers.serviceManagerProvider.overrideWithValue(widget.initialData.$1),
        providers.configServiceProvider.overrideWithValue(ConfigService.instance),
        providers.themeNotifierProvider.overrideWithValue(widget.initialData.$2),
      ],
      child: AppLifecycleObserver(
        child: AppShell(router: _router!),
      ),
    );
  }
}
